<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Models\received;
use App\Models\user;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\DB;

class AdminController extends Controller
{

    public function all_list(){
        return user::where('isadmin',0)->get();
    }

    public function call_list(){
        return User::where('call',1)->get();
    }

    public function getrecycle(Request $request,$id){
        $user = user::find($id);
        $user->call = 0;
        $user->save();

        $call = received::create([
            'user_id'=>$request['id']
        ]);

        $response = ['user'=>$user ,'message'=>'recycle stuff recived'];

        return Response($response,201);
    }

    public function recived_list(){}
}
