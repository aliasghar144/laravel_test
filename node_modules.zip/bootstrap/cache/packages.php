<?php return array (
  'laravel/sanctum' => 
  array (
    'providers' => 
    array (
      0 => 'Laravel\\Sanctum\\SanctumServiceProvider',
    ),
  ),
  'laravel/tinker' => 
  array (
    'providers' => 
    array (
      0 => 'Laravel\\Tinker\\TinkerServiceProvider',
    ),
  ),
  'nesbot/carbon' => 
  array (
    'providers' => 
    array (
      0 => 'Carbon\\Laravel\\ServiceProvider',
    ),
  ),
  'nunomaduro/termwind' => 
  array (
    'providers' => 
    array (
      0 => 'Termwind\\Laravel\\TermwindServiceProvider',
    ),
  ),
  'trez/raygan-sms' => 
  array (
    'providers' => 
    array (
      0 => 'Trez\\RayganSms\\RayganSmsServiceProvider',
    ),
    'aliases' => 
    array (
      'RayganSms' => 'Trez\\RayganSms\\Facades',
    ),
  ),
);